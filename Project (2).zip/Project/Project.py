import pandas as pd
import seaborn as sns
import matplotlib.pyplot as plt
import numpy as np
import collections
from sklearn.model_selection import LeaveOneGroupOut
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.naive_bayes import GaussianNB
from sklearn import tree
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import accuracy_score
from sklearn.metrics import f1_score


def preprocess(data):
    data['date_posted'] = pd.to_datetime(data['date_posted'])
    data['date_posted'] = (data['date_posted'] - data['date_posted'].min())  / np.timedelta64(1,'D')
    data['recommendation'] = data['recommendation'].replace(['Recommended','Not Recommended'],[True, False])

    fun_vote = data[['funny', 'title']]

    sns.set(rc = {'figure.figsize':(15,8)})
    sns.boxplot(y='funny', x='title',data=fun_vote)
    plt.xticks(rotation=90)

    fun_vote = fun_vote[fun_vote.funny < 10000]

    sns.set(rc = {'figure.figsize':(15,8)})
    sns.boxplot(y='funny', x='title',data=fun_vote)
    plt.xticks(rotation=90)

    help_vote = data[['helpful', 'title']]

    sns.set(rc = {'figure.figsize':(15,8)})
    sns.boxplot(y='helpful', x='title',data=help_vote)
    plt.xticks(rotation=90)

    data = data[data.funny < 10000]

    data['review'] = data['review'].fillna(0)

    data['review'].isnull().values.sum()

    data['review_length'] = data['review'].str.len()
    data['review_length'] = data['review_length'].fillna(0)

    data['review_length'].isnull().values.sum()

    data = data.drop('review', axis=1)

    data = data[data.review_length != 0]

    dataplot = sns.heatmap(data.corr())

    data = data.drop('date_posted', axis=1)

    dataplot = sns.heatmap(data.corr())

    titles = {}
    pos = 0
    for title in data.title:
        if title not in titles:
            titles[title] = pos
            pos += 1

    data['title'] = data.title.replace(titles)

    data = data.reset_index(drop=True)

    return data

def dictOfDataFrame(data):
    uniqueGames = data.title.unique()

    dataFrameDict = {elem: pd.DataFrame for elem in uniqueGames}

    for key in dataFrameDict.keys():
        dataFrameDict[key] = data[:][data.title == key]

    return dataFrameDict


def standard_scale(xTrain, xTest):
    scaler = StandardScaler()

    xTrain = scaler.fit_transform(xTrain)
    xTest = scaler.transform(xTest)

    return xTrain, xTest

def logRegSplitPerGame(dataFrameDict):
    print("Predicted recommendation percent per game using Logistic Regression")
    acc_list = []
    f1_list = []
    for key in dataFrameDict:
        if len(dataFrameDict[key]) > 100:
            game = pd.DataFrame(dataFrameDict[key].copy())
            y = game.pop('recommendation').astype(int)
            if len(y.unique()) == 1:
                continue
            else:
                X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(game, y, test_size=0.25)
                X_train_split, X_test_split = standard_scale(X_train_split, X_test_split)
                if len(y_train_split.unique()) == 1 or len(y_test_split.unique()) == 1:
                    continue
                else:
                    clf = LogisticRegression().fit(X_train_split, y_train_split)

                    y_pred_split = clf.predict(X_test_split)
                    count = collections.Counter(y_pred_split)
                    total = 0
                    for num in count:
                        total += count[num]

                    percent = (count[1] / total) * 100
                    if percent > 70:
                        print("Game " + str(key) + " is recommended at " + str(percent) + "%")
                    elif percent > 50:
                        print("Game " + str(key) + " has mixed recommendations at " + str(percent) + "%")
                    else:
                        print("Game " + str(key) + " is not recommended at " + str(percent) + "%")

                    y_true_split = y_test_split

                    accuracy = accuracy_score(y_true_split, y_pred_split)
                    f1 = f1_score(y_true_split, y_pred_split)

                    acc_list.append(accuracy)
                    f1_list.append(f1)
    print("Average accuracy and f1 scores across each game")
    print(np.mean(acc_list))
    print(np.mean(f1_list))

def decisionTreeSplitPerGame(dataFrameDict):
    print("Predicted recommendation percent per game using Decision Trees")
    acc_list = []
    f1_list = []
    for key in dataFrameDict:
        if len(dataFrameDict[key]) > 100:
            game = pd.DataFrame(dataFrameDict[key].copy())
            y = game.pop('recommendation').astype(int)
            if len(y.unique()) == 1:
                continue
            else:
                X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(game, y, test_size=0.25)
                if len(y_train_split.unique()) == 1 or len(y_test_split.unique()) == 1:
                    continue
                else:
                    clf = tree.DecisionTreeClassifier().fit(X_train_split, y_train_split)

                    y_pred_split = clf.predict(X_test_split)
                    count = collections.Counter(y_pred_split)
                    total = 0
                    for num in count:
                        total += count[num]

                    percent = (count[1] / total) * 100

                    if percent > 70:
                        print("Game " + str(key) + " is recommended at " + str(percent) + "%")
                    elif percent > 50:
                        print("Game " + str(key) + " has mixed recommendations at " + str(percent) + "%")
                    else:
                        print("Game " + str(key) + " is not recommended at " + str(percent) + "%")

                    y_true_split = y_test_split

                    accuracy = accuracy_score(y_true_split, y_pred_split)
                    f1 = f1_score(y_true_split, y_pred_split)

                    acc_list.append(accuracy)
                    f1_list.append(f1)
    print("Average accuracy and f1 scores across each game")
    print(np.mean(acc_list))
    print(np.mean(f1_list))

def gaussianSplitPerGame(dataFrameDict):
    print("Predicted recommendation percent per game using GaussianNB")
    acc_list = []
    f1_list = []
    for key in dataFrameDict:
        if len(dataFrameDict[key]) > 100:
            game = pd.DataFrame(dataFrameDict[key].copy())
            y = game.pop('recommendation').astype(int)
            if len(y.unique()) == 1:
                continue
            else:
                X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(game, y, test_size=0.25)
                if len(y_train_split.unique()) == 1 or len(y_test_split.unique()) == 1:
                    continue
                else:
                    clf = GaussianNB().fit(X_train_split, y_train_split)

                    y_pred_split = clf.predict(X_test_split)
                    count = collections.Counter(y_pred_split)
                    total = 0
                    for num in count:
                        total += count[num]

                    percent = (count[1] / total) * 100
                    if percent > 70:
                        print("Game " + str(key) + " is recommended at " + str(percent) + "%")
                    elif percent > 50:
                        print("Game " + str(key) + " has mixed recommendations at " + str(percent) + "%")
                    else:
                        print("Game " + str(key) + " is not recommended at " + str(percent) + "%")

                    y_true_split = y_test_split

                    accuracy = accuracy_score(y_true_split, y_pred_split)
                    f1 = f1_score(y_true_split, y_pred_split)

                    acc_list.append(accuracy)
                    f1_list.append(f1)
    print("Average accuracy and f1 scores across each game")
    print(np.mean(acc_list))
    print(np.mean(f1_list))

def logoDecisionTree(data):
    data = data.copy()
    y = data.pop('recommendation').astype(int)

    logo = LeaveOneGroupOut()

    acc = []
    f1 = []

    for train_index, test_index in logo.split(data, y, data.title):
        X_train, X_test = data.iloc[train_index], data.iloc[test_index]
        y_train, y_test = y[train_index], y[test_index]

        clf = tree.DecisionTreeClassifier().fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_true = y_test

        acc.append(accuracy_score(y_true, y_pred))
        f1.append(f1_score(y_true, y_pred))

    print("Average accuracy and f1 score for Decision Tree model with LOGO-CV:")
    print(np.mean(acc))
    print(np.mean(f1))

def logoLogReg(data):
    data = data.copy()
    y = data.pop('recommendation').astype(int)

    logo = LeaveOneGroupOut()

    acc = []
    f1 = []

    for train_index, test_index in logo.split(data, y, data.title):
        X_train, X_test = data.iloc[train_index], data.iloc[test_index]
        X_train, X_test = standard_scale(X_train, X_test)
        y_train, y_test = y[train_index], y[test_index]

        clf = LogisticRegression().fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_true = y_test

        acc.append(accuracy_score(y_true, y_pred))
        f1.append(f1_score(y_true, y_pred))
    print("Average accuracy and f1 score for Logistic Regression model with LOGO-CV:")
    print(np.mean(acc))
    print(np.mean(f1))

def logoGaussian(data):
    data = data.copy()
    y = data.pop('recommendation').astype(int)

    logo = LeaveOneGroupOut()

    acc = []
    f1 = []

    for train_index, test_index in logo.split(data, y, data.title):
        X_train, X_test = data.iloc[train_index], data.iloc[test_index]
        y_train, y_test = y[train_index], y[test_index]

        clf = GaussianNB().fit(X_train, y_train)

        y_pred = clf.predict(X_test)
        y_true = y_test

        acc.append(accuracy_score(y_true, y_pred))
        f1.append(f1_score(y_true, y_pred))

    print("Average accuracy and f1 score for GaussianNB model with LOGO-CV:")
    print(np.mean(acc))
    print(np.mean(f1))

def logRegSplit(data, y):
    X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(data, y, test_size=0.25)
    X_train_split, X_test_split = standard_scale(X_train_split, X_test_split)
    clf = LogisticRegression().fit(X_train_split, y_train_split)
    
    y_pred_split = clf.predict(X_test_split)
    
    y_true_split = y_test_split
    
    accuracy = accuracy_score(y_true_split, y_pred_split)
    f1 = f1_score(y_true_split, y_pred_split)
    
    return accuracy, f1


def decisionTreeSplit(data, y):
    X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(data, y, test_size=0.25)
    clf = tree.DecisionTreeClassifier().fit(X_train_split, y_train_split)
    
    y_pred_split = clf.predict(X_test_split)
    
    y_true_split = y_test_split
    
    accuracy = accuracy_score(y_true_split, y_pred_split)
    f1 = f1_score(y_true_split, y_pred_split)
    
    return accuracy, f1


def gaussianNBSplit(data, y):
    X_train_split, X_test_split, y_train_split, y_test_split = train_test_split(data, y, test_size=0.25)
    clf = GaussianNB().fit(X_train_split, y_train_split)
    
    y_pred_split = clf.predict(X_test_split)
    
    y_true_split = y_test_split
    
    accuracy = accuracy_score(y_true_split, y_pred_split)
    f1 = f1_score(y_true_split, y_pred_split)
    
    return accuracy, f1

def decisionTreeLoop(data):
    temp = data.copy()
    y = temp.pop('recommendation').astype(int)
    accuracy = []
    f1 = []
    for i in range(0,10):
        toAppend = decisionTreeSplit(temp, y)
        accuracy.append(toAppend[0])
        f1.append(toAppend[1])

    print("Average accuracy and f1 score for Decision Tree model with train/test split:")
    print(np.mean(accuracy))
    print(np.mean(f1))

def logRegLoop(data):
    temp = data.copy()
    y = temp.pop('recommendation').astype(int)
    accuracy = []
    f1 = []
    for i in range(0,10):
        toAppend = logRegSplit(temp, y)
        accuracy.append(toAppend[0])
        f1.append(toAppend[1])

    print("Average accuracy and f1 score for Logistic Regression model with train/test split:")
    print(np.mean(accuracy))
    print(np.mean(f1))

def gaussianLoop(data):
    temp = data.copy()
    y = temp.pop('recommendation').astype(int)
    accuracy = []
    f1 = []
    for i in range(0,10):
        toAppend = gaussianNBSplit(temp, y)
        accuracy.append(toAppend[0])
        f1.append(toAppend[1])

    print("Average accuracy and f1 score for GaussianNB model with train/test split:")
    print(np.mean(accuracy))
    print(np.mean(f1))

def main():
    data = pd.read_csv('steam_reviews.csv')

    data = preprocess(data)

    logoLogReg(data)
    logoDecisionTree(data)
    logoGaussian(data)

    logRegLoop(data)
    decisionTreeLoop(data)
    gaussianLoop(data)

    dataFrameDict = dictOfDataFrame(data)

    logRegSplitPerGame(dataFrameDict)
    decisionTreeSplitPerGame(dataFrameDict)
    gaussianSplitPerGame(dataFrameDict)

if __name__ == "__main__":
    main()